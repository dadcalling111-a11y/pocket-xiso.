# Pocket XISO — Android-focused web build

This is a mobile-friendly personal fork of the upstream `antangelo/xdvdfs` v0.8.3 source. It keeps the original Rust/WASM XISO operations and updates the web shell for narrow phone screens, larger touch targets, and a dark high-contrast layout.

## Build and deploy from an Android phone

1. Create a new GitHub repository named `pocket-xiso` (or another name).
2. Upload the **contents** of this ZIP to the repository root (so `.github/`, `Cargo.toml`, and `xdvdfs-web/` are at the root, not inside another nested folder).
3. In GitHub, open **Settings → Pages** and set the build/deployment source to **GitHub Actions**.
4. Open **Actions → Build and Deploy Pocket XISO → Run workflow**. A push to `main` also triggers a build.
5. When the workflow succeeds, open the Pages URL shown in the workflow deployment.

## Brave on Snapdragon 8+ Gen 1

- Open the deployed HTTPS URL in current Brave for Android.
- The app uses WebAssembly and performs image work locally in the browser; large images can still require substantial RAM and temporary storage. Close heavy tabs and keep the phone cool during large jobs.
- The browser UI relies on the File System Access API. If Brave on your device reports **Unsupported Browser** or does not expose the required directory/file picker, the web app cannot work around that browser limitation. Try the current stable Brave release and its standard site settings; this project does not bypass Android storage permissions.
- Avoid locking the screen or switching away during a large pack/unpack/compress operation.

## Notes

- This is a **source package with an automated build/deploy workflow**, not a precompiled APK and not a website already hosted for you. GitHub Actions compiles the Rust/WebAssembly app.
- The app's actual XISO functionality is inherited from upstream; this fork primarily changes mobile layout and deployment.
- Upstream project: https://github.com/antangelo/xdvdfs
- License: MIT. Preserve the upstream `LICENSE` and attribution when redistributing.
